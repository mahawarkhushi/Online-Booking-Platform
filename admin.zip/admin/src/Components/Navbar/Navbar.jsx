import React from 'react'
import './Navbar.css'

const Navbar = () => {
  return (
    <div>Navbar</div>
  )
}

export default Navbar